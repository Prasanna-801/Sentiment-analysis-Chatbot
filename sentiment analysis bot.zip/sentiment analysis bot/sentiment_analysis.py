import joblib
import numpy as np
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer

# Load the models
vectorizer = joblib.load('vectorizer.pkl')
nb_model = joblib.load('naive_bayes_model.pkl')

def preprocess(text):
    stop_words = set(stopwords.words('english'))
    lemmatizer = WordNetLemmatizer()
    words = word_tokenize(text.lower())
    words = [lemmatizer.lemmatize(word) for word in words if word.isalnum() and word not in stop_words]
    return ' '.join(words)

def get_sentiment(text):
    processed_input = preprocess(text)
    vectorized_input = vectorizer.transform([processed_input]).toarray()
    
    # Naive Bayes
    nb_pred = nb_model.predict(vectorized_input)[0]
    nb_sentiment = "Positive" if nb_pred == 1 else "Negative"

    return nb_sentiment

# Test with example text
user_input = "I am happy."
nb_sentiment = get_sentiment(user_input)
print(f"Naive Bayes: {nb_sentiment}")

# Start chatbot interaction
print("Hello! How are you feeling today?")
while True:
    user_input = input("You: ")
    if user_input.lower() in ['exit', 'bye']:
        print("Chatbot: Goodbye! Have a great day!")
        break
    try:
        nb_sentiment = get_sentiment(user_input)
        print(f"Chatbot: (Naive Bayes) Your sentiment is {nb_sentiment}.")
    except Exception as e:
        print(f"Chatbot: An error occurred: {e}")