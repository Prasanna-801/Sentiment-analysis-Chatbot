import joblib
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import classification_report
import numpy as np

# Load the preprocessed and vectorized data
# Assume 'data.pkl' contains X_train, X_test, y_train, y_test
X_train, X_test, y_train, y_test = joblib.load('data.pkl')

# Load the vectorizer
vectorizer = joblib.load('vectorizer.pkl')

# Check if X_train and X_test are numpy arrays, if not, transform them
if isinstance(X_train, np.ndarray) and isinstance(X_test, np.ndarray):
    X_train_vec = X_train
    X_test_vec = X_test
else:
    X_train_vec = vectorizer.transform(X_train)
    X_test_vec = vectorizer.transform(X_test)

# Train Naive Bayes model
nb_model = MultinomialNB()
nb_model.fit(X_train_vec, y_train)

# Save the Naive Bayes model
joblib.dump(nb_model, 'naive_bayes_model.pkl')

# Evaluate the Naive Bayes model
nb_y_pred = nb_model.predict(X_test_vec)

print("Naive Bayes Classification Report:\n", classification_report(y_test, nb_y_pred))
print("Naive Bayes model saved successfully.")