import nltk
from nltk.corpus import movie_reviews
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.model_selection import train_test_split
import joblib

# Download required NLTK datasets
nltk.download('movie_reviews')
nltk.download('punkt')
nltk.download('stopwords')
nltk.download('wordnet')

# Preprocessing function
def preprocess(text):
    from nltk.tokenize import word_tokenize
    from nltk.corpus import stopwords
    from nltk.stem import WordNetLemmatizer
    
    stop_words = set(stopwords.words('english'))
    lemmatizer = WordNetLemmatizer()
    
    words = word_tokenize(text.lower())
    words = [lemmatizer.lemmatize(word) for word in words if word.isalnum() and word not in stop_words]
    return ' '.join(words)

corpus = []
labels = []

# Prepare the dataset
for fileid in movie_reviews.fileids('pos'):
    corpus.append(preprocess(movie_reviews.raw(fileid)))
    labels.append(1)  # Positive sentiment

for fileid in movie_reviews.fileids('neg'):
    corpus.append(preprocess(movie_reviews.raw(fileid)))
    labels.append(0)  # Negative sentiment

# Vectorization (for traditional ML models)
vectorizer = CountVectorizer(max_features=3000)
X = vectorizer.fit_transform(corpus).toarray()
y = labels

# Train-Test Split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Save the vectorizer and data
joblib.dump(vectorizer, 'vectorizer.pkl')
joblib.dump((X_train, X_test, y_train, y_test), 'data.pkl')